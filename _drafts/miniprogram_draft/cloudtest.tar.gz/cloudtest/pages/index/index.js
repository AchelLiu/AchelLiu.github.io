Page({
  addLog(event){
    const add = event.currentTarget.dataset.add //固定的 add 与 data-add对应
    console.log("add",add)
    //获取缓存中的openid
    const ui = wx.getStorageSync('userinfo')  
    //判断是否登录
    if(!ui.openid){
      wx.switchTab({
        url: '/pages/me/me', //跳转到登录页面
      })
    }else{
      //调用云函数createlog
      wx.cloud.callFunction({
        name:"createlog",
        data:{
          add:add,
          date: Date.now(),
          openid:ui.openid
        }
      })
    }
  }
})